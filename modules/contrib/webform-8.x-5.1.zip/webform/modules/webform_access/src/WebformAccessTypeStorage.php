<?php

namespace Drupal\webform_access;

use Drupal\Core\Config\Entity\ConfigEntityStorage;

/**
 * Storage controller class for "webform_access_type" configuration entities.
 */
class WebformAccessTypeStorage extends ConfigEntityStorage implements WebformAccessTypeStorageInterface {

}
